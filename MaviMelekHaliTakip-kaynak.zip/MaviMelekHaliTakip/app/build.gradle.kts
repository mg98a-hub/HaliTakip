plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mavimelek.halitakip"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.mavimelek.halitakip"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
