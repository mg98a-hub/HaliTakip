package com.mavimelek.halitakip

import android.app.Activity
import android.os.Bundle
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class Order(val id: Long, val name: String, val phone: String, val address: String, val item: String, val sqm: Double, val total: Double, val deposit: Double, val paid: Double, val status: String, val date: String)

class Store(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "mavimelek.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,address TEXT,item TEXT,sqm REAL,total REAL,deposit REAL,paid REAL,status TEXT,date TEXT)")
        db.execSQL("CREATE TABLE prices(item TEXT PRIMARY KEY,price REAL)")
        listOf("Makine Halısı" to 120.0, "Shaggy Halı" to 150.0, "Yün Halı" to 180.0, "Yorgan" to 500.0, "Stor" to 80.0).forEach { (n,p) -> val v=ContentValues().apply { put("item",n); put("price",p) }; db.insert("prices",null,v) }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun prices(): List<Pair<String,Double>> { val c=readableDatabase.rawQuery("SELECT item,price FROM prices ORDER BY item",null); val a= mutableListOf<Pair<String,Double>>(); while(c.moveToNext()) a.add(c.getString(0) to c.getDouble(1)); c.close(); return a }
    fun setPrice(item:String, price:Double) { val v=ContentValues().apply { put("item",item); put("price",price) }; writableDatabase.insertWithOnConflict("prices",null,v,SQLiteDatabase.CONFLICT_REPLACE) }
    fun add(name:String,phone:String,address:String,item:String,sqm:Double,total:Double,deposit:Double) { val v=ContentValues().apply { put("name",name);put("phone",phone);put("address",address);put("item",item);put("sqm",sqm);put("total",total);put("deposit",deposit);put("paid",deposit);put("status","Alındı");put("date",SimpleDateFormat("dd.MM.yyyy HH:mm",Locale("tr","TR")).format(Date())) }; writableDatabase.insert("orders",null,v) }
    fun all():List<Order> { val c=readableDatabase.rawQuery("SELECT id,name,phone,address,item,sqm,total,deposit,paid,status,date FROM orders ORDER BY id DESC",null); val a= mutableListOf<Order>(); while(c.moveToNext()) a.add(Order(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getDouble(5),c.getDouble(6),c.getDouble(7),c.getDouble(8),c.getString(9),c.getString(10))); c.close(); return a }
    fun status(id:Long,s:String) { val v=ContentValues().apply { put("status",s) }; writableDatabase.update("orders",v,"id=?", arrayOf(id.toString())) }
    fun collect(id:Long) { val v=ContentValues().apply { put("paid", "total") }; writableDatabase.execSQL("UPDATE orders SET paid=total,status='Ödendi' WHERE id=?",arrayOf(id)) }
}

class MainActivity : Activity() {
    private lateinit var db: Store
    private lateinit var root: LinearLayout
    private val blue = Color.rgb(24,83,135)
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); db=Store(this); showHome() }
    private fun text(s:String,size:Float=16f,bold:Boolean=false):TextView = TextView(this).apply { text=s; textSize=size; setTextColor(Color.rgb(35,48,60)); if(bold) setTypeface(null,1); setPadding(dp(8),dp(8),dp(8),dp(8)) }
    private fun button(s:String, action:()->Unit):Button = Button(this).apply { text=s; isAllCaps=false; setOnClickListener { action() } }
    private fun field(hint:String):EditText = EditText(this).apply { this.hint=hint; textSize=16f; setSingleLine(true); setPadding(dp(12),dp(8),dp(12),dp(8)) }
    private fun base(title:String) { root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,249,252)); setPadding(dp(12),dp(8),dp(12),dp(8)) }; val header=TextView(this).apply { text="MAVİ MELEK\n$title"; textSize=21f; setTextColor(Color.WHITE); setTypeface(null,1); gravity=Gravity.CENTER; setBackgroundColor(blue); setPadding(dp(8),dp(14),dp(8),dp(14)) }; root.addView(header,LinearLayout.LayoutParams(-1,-2)); val scroll=ScrollView(this); val content=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(0,dp(8),0,dp(12)) }; scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f)); val nav=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setBackgroundColor(Color.WHITE) }; listOf("Bugün","Siparişler","Müşteriler","Fiyat & Araçlar","Yeni Sipariş").forEach { label -> nav.addView(Button(this).apply { text=label; textSize=10f; isAllCaps=false; setPadding(0,0,0,0); setOnClickListener { when(label){"Bugün"->showHome();"Siparişler"->showOrders();"Müşteriler"->showCustomers();"Fiyat & Araçlar"->showPrices();else->showNewOrder()} } },LinearLayout.LayoutParams(0,dp(52),1f)) }; root.addView(nav); setContentView(root); root.tag=content }
    private fun content()= root.tag as LinearLayout
    private fun add(v:View) { content().addView(v,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(5) }) }
    private fun showHome(){ base("HALI TAKİP"); val orders=db.all(); add(text("Bugünün özeti",20f,true)); add(text("Toplam sipariş: ${orders.size}")); add(text("Bekleyen tahsilat: ${money(orders.sumOf { (it.total-it.paid).coerceAtLeast(0.0) })}")); add(text("Yıkamada: ${orders.count{it.status=="Yıkamada"}}  •  Teslime hazır: ${orders.count{it.status=="Teslime Hazır"}}")); add(button("+ Yeni Sipariş"){showNewOrder()}); add(button("Siparişleri Gör"){showOrders()}); add(text("Son siparişler",18f,true)); orders.take(5).forEach { orderCard(it) } }
    private fun showNewOrder(){ base("YENİ SİPARİŞ"); val name=field("Müşteri adı soyadı"); val phone=field("Telefon"); val address=field("Adres / Mahalle"); val item=Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,db.prices().map{it.first}) }; val w=field("En (metre)"); val h=field("Boy (metre)"); val discount=field("İskonto (₺) - isteğe bağlı"); val deposit=field("Kapora (₺)"); val calc=text("Metrekare: 0,00 m²   Toplam: 0 ₺",18f,true); listOf(name,phone,address).forEach{add(it)}; add(text("Halı türü")); add(item); add(w); add(h); add(discount); add(deposit); add(button("Hesapla"){ calc.text="Metrekare: ${sqm(w,h)} m²   Toplam: ${money(total(item,w,h,discount))}" }); add(calc); add(button("SİPARİŞİ KAYDET"){ val n=name.text.toString().trim(); val ww=w.text.toString().replace(',','.').toDoubleOrNull()?:0.0; val hh=h.text.toString().replace(',','.').toDoubleOrNull()?:0.0; if(n.isBlank()||ww<=0||hh<=0){toast("Müşteri adı, en ve boy zorunludur.");return@button}; val sq=ww*hh; val t=total(item,w,h,discount); val d=deposit.text.toString().replace(',','.').toDoubleOrNull()?:0.0; db.add(n,phone.text.toString(),address.text.toString(),item.selectedItem.toString(),sq,t,d.coerceIn(0.0,t)); toast("Sipariş kaydedildi"); showOrders() }) }
    private fun sqm(w:EditText,h:EditText)="%.2f".format(Locale.US,(w.text.toString().replace(',','.').toDoubleOrNull()?:0.0)*(h.text.toString().replace(',','.').toDoubleOrNull()?:0.0))
    private fun total(sp:Spinner,w:EditText,h:EditText,d:EditText):Double { val s=(w.text.toString().replace(',','.').toDoubleOrNull()?:0.0)*(h.text.toString().replace(',','.').toDoubleOrNull()?:0.0); val p=db.prices().firstOrNull{it.first==sp.selectedItem?.toString()}?.second?:0.0; return (s*p-(d.text.toString().replace(',','.').toDoubleOrNull()?:0.0)).coerceAtLeast(0.0) }
    private fun showOrders(){ base("SİPARİŞLER"); val search=field("Müşteri veya adres ara"); add(search); val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; add(list); fun refresh(){list.removeAllViews(); db.all().filter{it.name.contains(search.text.toString(),true)||it.address.contains(search.text.toString(),true)||it.phone.contains(search.text.toString(),true)}.forEach{ val b=button("#${it.id} • ${it.name}\n${it.item} ${it.sqm} m² • ${money(it.total)} • ${it.status}"){showDetail(it)}; list.addView(b) }}; search.addTextChangedListener(SimpleWatcher{refresh()}); refresh() }
    private fun orderCard(o:Order){add(button("#${o.id}  ${o.name}  •  ${o.status}\n${o.item} ${o.sqm} m²  •  Kalan ${money((o.total-o.paid).coerceAtLeast(0.0))}"){showDetail(o)})}
    private fun showDetail(o:Order){base("SİPARİŞ DETAYI #${o.id}"); add(text("${o.name}\n${o.phone}\n${o.address}\n${o.item} • ${o.sqm} m²\nToplam: ${money(o.total)}\nÖdenen: ${money(o.paid)}\nKalan: ${money((o.total-o.paid).coerceAtLeast(0.0))}\nDurum: ${o.status}",18f)); add(button("Durumu: Alındı"){db.status(o.id,"Alındı");showDetail(db.all().first{it.id==o.id})}); add(button("Durumu: Yıkamada"){db.status(o.id,"Yıkamada");showDetail(db.all().first{it.id==o.id})}); add(button("Durumu: Kurutmada"){db.status(o.id,"Kurutmada");showDetail(db.all().first{it.id==o.id})}); add(button("Durumu: Teslime Hazır"){db.status(o.id,"Teslime Hazır");showDetail(db.all().first{it.id==o.id})}); add(button("KALAN BAKİYEYİ TAHSİL ET"){db.collect(o.id);toast("Bakiye kapatıldı");showDetail(db.all().first{it.id==o.id})}); add(button("WhatsApp bilgi fişi paylaş"){val msg="MAVİ MELEK HALI YIKAMA\nSipariş #${o.id}\nMüşteri: ${o.name}\nHalı: ${o.item}\nÖlçü: ${o.sqm} m²\nToplam: ${money(o.total)}\nÖdenen: ${money(o.paid)}\nKalan: ${money((o.total-o.paid).coerceAtLeast(0.0))}\nDurum: ${o.status}"; share(msg)}); add(button("Adresi haritada aç"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("geo:0,0?q="+Uri.encode(o.address))))}); add(button("Telefonu ara"){if(o.phone.isNotBlank())startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+o.phone)))}) }
    private fun showCustomers(){base("MÜŞTERİLER"); val seen=db.all().distinctBy{it.phone.ifBlank{it.name}}; seen.forEach{ o-> val related=db.all().filter{it.phone==o.phone}; add(button("${o.name}\n${o.phone} • ${related.size} sipariş • Borç ${money(related.sumOf{(it.total-it.paid).coerceAtLeast(0.0)})}"){showDetail(o)}) } }
    private fun showPrices(){base("FİYAT & ARAÇLAR"); db.prices().forEach{(n,p)-> val e=field("${n} fiyatı (₺/m²)");e.setText(p.toString());add(text(n,17f,true));add(e);add(button("${n} fiyatını kaydet"){val v=e.text.toString().replace(',','.').toDoubleOrNull();if(v==null||v<0)toast("Geçerli fiyat gir")else{db.setPrice(n,v);toast("Fiyat kaydedildi")}})}; add(text("Hızlı hesaplayıcı",20f,true)); val w=field("En (metre)");val h=field("Boy (metre)"); val sp=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,db.prices().map{it.first})};val out=text("Sonuç burada");add(w);add(h);add(sp);add(button("HESAPLA"){val sq=(w.text.toString().replace(',','.').toDoubleOrNull()?:0.0)*(h.text.toString().replace(',','.').toDoubleOrNull()?:0.0);val p=db.prices().firstOrNull{it.first==sp.selectedItem?.toString()}?.second?:0.0;out.text="${sq} m² × ${money(p)} = ${money(sq*p)}"});add(out) }
    private fun share(s:String){val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,s)};startActivity(Intent.createChooser(i,"Bilgi fişini paylaş"))}
    private fun money(v:Double)="%,.0f ₺".format(Locale("tr","TR"),v)
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}

private class SimpleWatcher(val changed:()->Unit): android.text.TextWatcher { override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){changed()};override fun afterTextChanged(s:android.text.Editable?){} }
